# CLO-SKET Paper I — IVC submission files

Scientific freeze: `paper-i-ivc-submission-2026-08-29` / commit `bb9b903`.

## Upload to Image and Vision Computing

- `CLO_SKET_IVC_Manuscript.docx` — editable main manuscript
- `CLO_SKET_IVC_Manuscript.pdf` — rendered reference copy
- `CLO_SKET_IVC_Highlights.docx` — separate Highlights file
- `CLO_SKET_IVC_Supplement.docx` — editable Supplementary Material
- `CLO_SKET_IVC_Supplement.pdf` — rendered Supplementary Material
- `Figures/Figure_1_Radial_Angular_Construction.png`
- `Figures/Figure_2_Provenance_Locked_14D_Representation.png`
- `Figures/Figure_3_Rigid_Rotation_Control.png`

Figures 4–6 are supplementary artwork and are included in `Figures/` for the Supplementary Material.

## Provenance/source copies

The Markdown manuscript, supplement, highlights, bibliography, formatted references, and package manifest are included for reproducibility and are not intended as separate journal uploads unless requested by the editorial system.

No graphical abstract is included.
